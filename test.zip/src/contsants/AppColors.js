const AppColors={
    primaryColor:'#3563E9',
    secondaryTextColor: '#90A3BF',
    primaryTextColor:'#3563E9',
    textInputBackgroundColor:'#F6F7F9'
};

export default AppColors;