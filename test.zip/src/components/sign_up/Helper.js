import { Alert } from "react-native";

export default class Helper {

    static isEmailValid(email) {

       let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
       return reg.test(email) == true;
  }

  static isFieldEmpty(txt){
    return txt.length === 0; 
  }

  static showAlert(message){
    Alert.alert(message)
  }

  static isLogin(email, password){

    //Post DATA
    var authorizationToken='';
    var userDeatils;

  }

}