export const GOOGLE_MAP_KEY = "AIzaSyBa2ozEcLg_aU9nrsqxfz3_2dWc30s3cLo";

export const PRIMARY_COLOR='978ff7'
export const SECONDARY_COLOR='9716fbc'
export const BLACK_COLOR='242420'

export const APP_NAME='CarRental'
export const FONT_REGULAR='PlusJakartaSans-Regular';
export const FONT_BOLD='PlusJakartaSans-Regular-Bold';


